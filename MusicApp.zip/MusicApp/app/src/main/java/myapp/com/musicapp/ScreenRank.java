package myapp.com.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class ScreenRank extends AppCompatActivity {
    Button btnLoveSong;
    Button btnEDM;
    Button btnUsUk;
    Button btnVpop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_screen_rank );
        btnLoveSong = (Button)findViewById(R.id.btnLoveSong);
        btnEDM = (Button)findViewById(R.id.btnEDM);
        btnVpop = (Button)findViewById(R.id.btnVpop);
        btnUsUk = (Button)findViewById(R.id.btnUsUk);
        btnLoveSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ScreenRank.this, LoveSong.class);
                startActivity(intent);
            }
        });
        btnEDM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ScreenRank.this, EDM.class);
                startActivity(intent);
            }
        });
        btnVpop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ScreenRank.this, VPOP.class);
                startActivity(intent);
            }
        });
        btnUsUk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ScreenRank.this, USUK.class);
                startActivity(intent);
            }
        });

    }
}
