package myapp.com.musicapp;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ScreenHome extends Activity {
    DatabaseReference mData;
    private ListView lvbhmoi;
    ArrayList<String> arrStringSong;
    ArrayList<Song> arrSong;
    ArrayAdapter adapter = null;
    public Song playSong;
    public Song InfoSong;

    public static final String TENBH = "TENBH";
    public static final String TheLoai = "TheLoai";
    public static final String Link = "Link";
    public static final String TenAB = "TenAB";
    public static final String TenCS = "TenCS";
    public static final String File = "File";
    List<Song> data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_screen_home );

        mData = FirebaseDatabase.getInstance().getReference();
        lvbhmoi = findViewById( R.id.lvbhmoi );
        arrStringSong = new ArrayList<String>();
        arrSong = new ArrayList<Song>();
        adapter = new ArrayAdapter( this, android.R.layout.simple_list_item_1, arrStringSong );
        lvbhmoi.setAdapter( adapter );
        registerForContextMenu(lvbhmoi);
        mData.child( "BaiHat" ).addChildEventListener( new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Song song = dataSnapshot.getValue( Song.class );
                arrStringSong.add( song.getTenBH() + " - " + song.getTenCS() );
                arrSong.add( song );
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        } );

        lvbhmoi.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                byExtras( i );
            }
        } );
        lvbhmoi.setOnItemLongClickListener( new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                InfoSong = arrSong.get( i );

                PopupMenu popup = new PopupMenu( ScreenHome.this, lvbhmoi );
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate( R.menu.menu_info, popup.getMenu() );
                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener( new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        switch(item.getItemId())
                        {
                            case R.id.info:
                                //Intent intent = new Intent( ScreenHome.this, Info.class );
                                InfoExtras( InfoSong );

                                //startActivity(intent);
                                break;

                        }
                        return true;
                    }
                } );
                popup.show();//showing popup menu
                return true;
            }
        } );//closing the setOnClickListener method

   }
//    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
//        super.onCreateContextMenu(menu, v, menuInfo);
//        getMenuInflater().inflate(R.menu.menu_info, menu);
//    }
//    //Xử lý sự kiện khi click vào từng item
//    @Override
//    public boolean onContextItemSelected(MenuItem item) {
//        switch (item.getItemId()){
//            case R.id.info:
//                //Toast.makeText(getApplicationContext(),"Red clicked", Toast.LENGTH_SHORT).show();
//
//                break;
//
//        }
//        return super.onContextItemSelected(item);
//    }


    public void byExtras(int position) {
        Intent intent = new Intent(ScreenHome.this, PlayMusic.class);
        intent.putExtra("ListSize",arrSong.size());
        for (int i=0;i<arrSong.size();i++) {
            intent.putExtra("TENBH"+i, arrSong.get(i).getTenBH());
            intent.putExtra("TenCS"+i, arrSong.get(i).getTenCS());
            intent.putExtra("TenAB"+i, arrSong.get(i).getTenAB());
            intent.putExtra("TheLoai"+i, arrSong.get(i).getTheLoai());
            intent.putExtra("Link"+i, arrSong.get(i).getLink());
            intent.putExtra("File"+i, arrSong.get(i).getFile());
        }
        intent.putExtra("position",position);
        startActivity(intent);
    }

    public void InfoExtras(Song sendSong) {
        Intent intent = new Intent( ScreenHome.this, Info.class );
        intent.putExtra( TENBH, sendSong.getTenBH() );
        intent.putExtra( TenCS, sendSong.getTenCS() );
        intent.putExtra( TenAB, sendSong.getTenAB() );
        intent.putExtra( TheLoai, sendSong.getTheLoai() );
        startActivity( intent );
    }

}