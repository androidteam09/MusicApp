package myapp.com.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TabHost;
@SuppressWarnings("deprecation")
public class OnlineScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online_screen);
        TabHost tabHost = (TabHost) findViewById(android.R.id.tabhost);

        TabHost.TabSpec tabHome = tabHost.newTabSpec("HOME");
        TabHost.TabSpec tabRank = tabHost.newTabSpec("RANK");

        tabHome.setIndicator("HOME",getResources().getDrawable((R.mipmap.ic_launcher)));
        tabHome.setContent(new Intent(this, ScreenHome.class));

        tabRank.setIndicator("RANK");
        tabRank.setContent(new Intent(this, ScreenRank.class));



        tabHost.addTab(tabHome);
        tabHost.addTab(tabRank);

    }
}
