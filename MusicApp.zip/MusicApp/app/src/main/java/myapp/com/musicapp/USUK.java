package myapp.com.musicapp;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class USUK extends AppCompatActivity {

    DatabaseReference mData;
    private ListView lvusuk;
    ArrayList<String> arrStringSong;
    ArrayList<Song> arrSong;
    ArrayAdapter adapter=null;
    public Song playSong;
    public Song InfoSong;
    public static final String TENBH  = "TENBH";
    public static final String TheLoai= "TheLoai";
    public static final String Link   = "Link";
    public static final String TenAB  = "TenAB";
    public static final String TenCS  = "TenCS";
    public static final String File   = "File";
    String Album;
    List<Song> data = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuk);

        mData = FirebaseDatabase.getInstance().getReference();
        lvusuk = findViewById(R.id.lvusuk);
        arrStringSong = new ArrayList<String>();
        arrSong = new ArrayList<Song>();
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrStringSong);
        lvusuk.setAdapter(adapter);
        mData.child("BaiHat").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Song song =dataSnapshot.getValue(Song.class);
                if(song.getTheLoai().equals( "US-UK" ) ){
                    arrStringSong.add(song.getTenBH()+ " - " + song.getTenCS());
                    arrSong.add(song);
                    adapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        lvusuk.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                byExtras(i);
            }
        });
        lvusuk.setOnItemLongClickListener( new AdapterView.OnItemLongClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                InfoSong = arrSong.get( i );
                PopupMenu popup = new PopupMenu( USUK.this, lvusuk );
                //popup.setGravity( BIND_ABOVE_CLIENT );
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate( R.menu.menu_info, popup.getMenu() );
                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener( new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.info:
                                //Intent intent = new Intent( ScreenHome.this, Info.class );
                                InfoExtras( InfoSong );

                                //startActivity(intent);
                                break;

                        }
                        return true;
                    }
                } );

                popup.show();//showing popup menu
                return true;
            }
        } );//closing the setOnClickListener method
    }

    public void byExtras(int position) {
        Intent intent = new Intent(USUK.this, PlayMusic.class);
        intent.putExtra("ListSize",arrSong.size());
        for (int i=0;i<arrSong.size();i++) {
            intent.putExtra("TENBH"+i, arrSong.get(i).getTenBH());
            intent.putExtra("TenCS"+i, arrSong.get(i).getTenCS());
            intent.putExtra("TenAB"+i, arrSong.get(i).getTenAB());
            intent.putExtra("TheLoai"+i, arrSong.get(i).getTheLoai());
            intent.putExtra("Link"+i, arrSong.get(i).getLink());
            intent.putExtra("File"+i, arrSong.get(i).getFile());
        }
        intent.putExtra("position",position);
        startActivity(intent);
    }

    //
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate( savedInstanceState );
//        setContentView( R.layout.activity_love_song );
//    }
    public void InfoExtras(Song sendSong) {
        Intent intent = new Intent( USUK.this, Info.class );
        intent.putExtra( TENBH, sendSong.getTenBH() );
        intent.putExtra( TenCS, sendSong.getTenCS() );
        intent.putExtra( TenAB, sendSong.getTenAB() );
        intent.putExtra( TheLoai, sendSong.getTheLoai() );
        startActivity( intent );
    }
}

