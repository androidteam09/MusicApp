package myapp.com.musicapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by MSI on 4/27/2018.
 */

public class SongAdapter extends BaseAdapter {

    Context context;
    int layout;
    ArrayList<Song> SongArrayList ;

    public SongAdapter(Context context, int layout, ArrayList<Song> songtArrayList) {
        this.context = context;
        this.layout = layout;
        this.SongArrayList = songtArrayList;
    }


    @Override
    public int getCount() {
        return SongArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if(view==null)
        {
            viewHolder = new ViewHolder();
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.row_offline_song,null);
            viewHolder.txtTenBaiHat = view.findViewById(R.id.txtTenBaiHat);
            viewHolder.txtTenCaSi = view.findViewById(R.id.txtTenCaSi);
            view.setTag(viewHolder);
        }
        else
        {
            viewHolder = (ViewHolder) view.getTag();

        }
        Song song = SongArrayList.get(i);
        viewHolder.txtTenBaiHat.setText(song.getTenBH());
        viewHolder.txtTenCaSi.setText(song.getTenCS());
        return view;
    }
    private class ViewHolder
    {
        TextView txtTenBaiHat;
        TextView txtTenCaSi;
    }
}