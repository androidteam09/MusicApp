package myapp.com.musicapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class PlayMusic extends AppCompatActivity {

    TextView txtTitle, txtTimeSong, txtTimeTotal;
    SeekBar skSong;
    ImageButton btnPrev, btnPlay, btnStop, btnNext;
    ImageView imgDisc;
    int position = 0;
    MediaPlayer mediaPlayer;
    ArrayList<Song> arraySong = new ArrayList<Song>();
    Animation animation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_music);
        AnhXa();
        GetSong();
        KhoiTaoMediaPlayer();
        animation = AnimationUtils.loadAnimation(PlayMusic.this,R.anim.disc_rotate);
        btnPlay.setImageResource(R.drawable.stop);
        SetTimeTotal();
        UpdateTimeSong();
        imgDisc.startAnimation(animation);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mediaPlayer.isPlaying()){
                    mediaPlayer.pause();
                    btnPlay.setImageResource(R.drawable.play);
                    imgDisc.clearAnimation();
                }
                else {
                    mediaPlayer.start();
                    btnPlay.setImageResource(R.drawable.stop);
                    SetTimeTotal();
                    UpdateTimeSong();
                    imgDisc.startAnimation(animation);
                }
            }
        });
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position++;
                if(position > arraySong.size()-1){
                    position=0;
                }
                if (mediaPlayer.isPlaying())
                    mediaPlayer.stop();
                KhoiTaoMediaPlayer();
                mediaPlayer.start();
                btnPlay.setImageResource(R.drawable.stop);
                SetTimeTotal();
            }
        });
        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position--;
                if(position < 0){
                    position=arraySong.size()-1;
                }
                if (mediaPlayer.isPlaying())
                    mediaPlayer.stop();
                KhoiTaoMediaPlayer();
                mediaPlayer.start();
                btnPlay.setImageResource(R.drawable.stop);
                SetTimeTotal();
            }
        });

        skSong.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(skSong.getProgress());
            }
        });
    }
    private void UpdateTimeSong(){
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat dinhDangGio = new SimpleDateFormat("mm:ss");
                txtTimeSong.setText(dinhDangGio.format(mediaPlayer.getCurrentPosition()));
                skSong.setProgress(mediaPlayer.getCurrentPosition());
                handler.postDelayed(this,1);
            }
        },10);
    }

    private void AnhXa() {
        txtTimeSong = (TextView) findViewById(R.id.txtTimeSong);
        txtTitle = (TextView) findViewById(R.id.txtTitle);
        txtTimeTotal = (TextView) findViewById(R.id.txtTimeTotal);
        skSong = (SeekBar) findViewById(R.id.seekBarSong);
        btnNext = (ImageButton) findViewById(R.id.imageButtonNext);
        btnPlay = (ImageButton) findViewById(R.id.imageButtonPlay);
        btnStop = (ImageButton) findViewById(R.id.imageButtonStop);
        btnPrev = (ImageButton) findViewById(R.id.imageButtonPrevious);
        imgDisc = (ImageView) findViewById(R.id.imgViewDisc);
    }

    private void KhoiTaoMediaPlayer(){

        if (MainActivity.tempMediaPlayer != null)
        {
            if (MainActivity.tempMediaPlayer.isPlaying())
                MainActivity.tempMediaPlayer.stop();
        }
        if(arraySong.get(position).getFile().equals("")) {
            mediaPlayer = MediaPlayer.create(PlayMusic.this, Uri.parse(arraySong.get(position).getLink()));
            MainActivity.tempMediaPlayer = mediaPlayer;
            mediaPlayer.start();
            txtTitle.setText(arraySong.get(position).getTenBH());
        }
        else{
            Uri u =Uri.parse(arraySong.get(position).getFile());
            mediaPlayer = MediaPlayer.create(getApplicationContext(),u);
            MainActivity.tempMediaPlayer = mediaPlayer;
            mediaPlayer.start();
            txtTitle.setText(arraySong.get(position).getTenBH());
        }

    }
    private void SetTimeTotal(){
        SimpleDateFormat dinhDangGio= new SimpleDateFormat("mm:ss");
        txtTimeTotal.setText(dinhDangGio.format(mediaPlayer.getDuration()));
        skSong.setMax(mediaPlayer.getDuration());
    }
    private  void GetSong(){
        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        int ListSize = b.getInt("ListSize",0);
        for (int i=0;i<ListSize;i++) {
            String playingSongName = b.getString("TENBH"+i);
            String playingSongSinger = b.getString("TenCS"+i);
            String playingSongKind = b.getString("TenAB"+i);
            String playingSongAlbum = b.getString("TheLoai"+i);
            String playingSongLink = b.getString("Link"+i);
            String playingSongFile = b.getString("File"+i);
            Song newSong = new Song(playingSongName, playingSongKind, playingSongLink, playingSongAlbum, playingSongSinger, playingSongFile);
            arraySong.add(newSong);
        }
        position = b.getInt("position",0);

    }
}