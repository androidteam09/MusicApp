package myapp.com.musicapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

import java.io.File;
import java.util.ArrayList;

public class OfflineList extends AppCompatActivity {
    ListView lvDsOffline;
    ArrayList<Song> arrSong;
    SongAdapter songAdapter;
    SQLite db;
    String[] item;
    public Song playSong;
    public static final String TENBH  = "TENBH";
    public static final String TheLoai= "TheLoai";
    public static final String Link   = "Link";
    public static final String TenAB  = "TenAB";
    public static final String TenCS  = "TenCS";
    public static final String File   = "File";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline_list);
        db = new SQLite(this,"Song.SQLite",null,1);
        lvDsOffline = findViewById(R.id.lvDsOffline);
        arrSong = new ArrayList<Song>();
        songAdapter = new SongAdapter(this, R.layout.row_offline_song, arrSong);
        lvDsOffline.setAdapter(songAdapter);
        initOfflineSong();
        getdataSong();
        final ArrayList<java.io.File> mySongs= findSong(getExternalFilesDir( "/SDCARD/" ));
        item=new String[mySongs.size()];
        for (int i =0; i<mySongs.size();i++)
        {
            item[i] =mySongs.get(i).getName().toString().replace(".mp3","").replace(".wav","");
        }
        getFileSong( mySongs );
        lvDsOffline.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                byExtras(i);
            }
        });
        lvDsOffline.setOnItemLongClickListener( new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                playSong = arrSong.get( i );
                PopupMenu popup = new PopupMenu( OfflineList.this, lvDsOffline );
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate( R.menu.menu_playlist, popup.getMenu() );
                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener( new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menuplaylist:
                                //Intent intent = new Intent( ScreenHome.this, Info.class );
                                addExtras( playSong );
                                //startActivity(intent);
                                break;

                        }
                        return true;
                    }
                } );

                popup.show();//showing popup menu
                return true;
            }
        } );//closing the setOnClickListener method
    }
    private void initOfflineSong()
    {
        db.QueryData("CREATE TABLE IF NOT EXISTS BAIHAT(TenBH VARCHAR, TheLoai VARCHAR,Link VARCHAR, TenAB VARCHAR, TenCS VARCHAR, FILE INTEGER)");
        db.QueryData("DELETE FROM BAIHAT");
        db.QueryData("INSERT INTO BaiHat VALUES('Cô Gái M52', 'Pop Music' , '' , 'LoveSong' , 'Huynh Tung Viu' ,'cogaim52huytungviu')");
        db.QueryData("INSERT INTO BaiHat VALUES('Ngắm Hoa Lệ Rơi', 'Pop Music','' ,'LoveSong', 'Chau Hai Phong','ngamhoaleroichauhaiphong')");
//        db.QueryData("INSERT INTO BaiHat VALUES('Buon Cua Anh', 'Pop Music' , '' , 'LoveSong' , 'KICM & Dat G & Masew' ,'BuonCuaAnh-KICMDatGMasew-5322411')");
//        db.QueryData("INSERT INTO BaiHat VALUES('CungAnh', 'Pop Music','' ,'LoveSong', 'Ngoc Dolil & Hagi Stee','CungAnh-NgocDolilHagiStee-5237527')");
//        db.QueryData("INSERT INTO BaiHat VALUES('Friends', 'Pop Music' , '' , 'LoveSong' , 'Marshmello & Anne Marie' ,'Friends-MarshmelloAnneMarie-5385096')");
//        db.QueryData("INSERT INTO BaiHat VALUES('Im Not Her', 'Pop Music','' ,'LoveSong', 'Clara Mae','ImNotHer-ClaraMae-5382889')");
//        db.QueryData("INSERT INTO BaiHat VALUES('No Tears Left To Cry', 'Pop Music' , '' , 'LoveSong' , 'Ariana Grande' ,'NoTearsLeftToCry-ArianaGrande-5458004')");
//        db.QueryData("INSERT INTO BaiHat VALUES('NguoiAmPhu', 'Pop Music','' ,'LoveSong', 'Mai Quang Nam','NguoiAmPhu-MaiQuangNam-5430437')");
//        db.QueryData("INSERT INTO BaiHat VALUES('Nguoi La Oi', 'Pop Music','' ,'LoveSong','Karik', 'Nguoi-La-Oi-Karik-Orange-Superbrothers')");
//        db.QueryData("INSERT INTO BaiHat VALUES('So Far Away', 'Pop Music','' ,'LoveSong', 'Martin Garrix','SoFarAway-MartinGarrixDavidGuettaJamieScottRomyDya-5298615')");
//        db.QueryData("INSERT INTO BaiHat VALUES('The River', 'Pop Music','' ,'LoveSong','Axel Johansson','TheRiver-AxelJohansson-5280558')");
    }
    private void getdataSong() {
        Cursor dataSong = db.GetData("SELECT * FROM BAIHAT");
        arrSong.clear();
        while (dataSong.moveToNext())
        {
            arrSong.add(new Song(dataSong.getString(0),dataSong.getString(1),dataSong.getString(2),dataSong.getString(3),dataSong.getString(4),dataSong.getString(5)));
        }
        songAdapter.notifyDataSetChanged();
    }
    public ArrayList<java.io.File> findSong(File root)
    {
        ArrayList<File> al = new ArrayList<File>();
        File[] files = root.listFiles();
        for(File singleFile:files)
        {
            if(singleFile.isDirectory() && !singleFile.isHidden()){
                al.addAll(findSong(singleFile));
            }
            else {
                if(singleFile.getName().endsWith(".mp3")){
                    al.add(singleFile);
                }
            }
        }
        return al;
    }
    private void getFileSong(ArrayList<File> mySongs){
        for(int i=0; i<arrSong.size();i++)
        {
            for (int j =0;j<item.length;j++) {
                if (arrSong.get(i).getFile().equals(item[j])) {
                    arrSong.get(i).setFile(mySongs.get(j).toString());
                }
            }
        }
    }
    public void byExtras(int position)
    {
        Intent intent = new Intent(OfflineList.this, PlayMusic.class);
        intent.putExtra("ListSize",arrSong.size());
        for (int i=0;i<arrSong.size();i++) {
            intent.putExtra("TENBH"+i, arrSong.get(i).getTenBH());
            intent.putExtra("TenCS"+i, arrSong.get(i).getTenCS());
            intent.putExtra("TenAB"+i, arrSong.get(i).getTenAB());
            intent.putExtra("TheLoai"+i, arrSong.get(i).getTheLoai());
            intent.putExtra("Link"+i, arrSong.get(i).getLink());
            intent.putExtra("File"+i, arrSong.get(i).getFile());
        }
        intent.putExtra("position",position);
        startActivity(intent);
    }public void addExtras(Song sendSong)
    {
        Intent intent = new Intent( OfflineList.this, Playlist.class );
        intent.putExtra( TENBH, sendSong.getTenBH() );
        intent.putExtra( TenCS, sendSong.getTenCS() );
        intent.putExtra( TenAB, sendSong.getTenAB() );
        intent.putExtra( TheLoai, sendSong.getTheLoai() );
        intent.putExtra(Link,sendSong.getLink());
        intent.putExtra(File,sendSong.getFile());
        startActivity( intent );
    }
}
