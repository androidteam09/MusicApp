package myapp.com.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.GetChars;
import android.widget.TextView;

public class Info extends AppCompatActivity {
    private TextView tenbh, tencs,tenab,theloai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_info );
        setControl();
        tenbh.setText( getIntent().getStringExtra( ScreenHome.TENBH ));
        tencs.setText( getIntent().getStringExtra( ScreenHome.TenCS ) );
        tenab.setText( getIntent().getStringExtra( ScreenHome.TenAB ) );
        theloai.setText( getIntent().getStringExtra( ScreenHome.TheLoai ) );
    }

    private void setControl(){
        tenbh = findViewById( R.id.TenBH );
        tencs = findViewById( R.id.TenCS );
        tenab = findViewById( R.id.TenAB );
        theloai = findViewById( R.id.TheLoai );
    }
}
