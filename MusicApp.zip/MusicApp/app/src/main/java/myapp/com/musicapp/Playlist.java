package myapp.com.musicapp;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.QuickContactBadge;

import java.io.File;
import java.util.ArrayList;

public class Playlist extends AppCompatActivity {
    Song playingSong;
    private ListView lvplaylist;
    ArrayList<String> arrStringSong;
    ArrayList<Song> arrSong;
    //ArrayList<Song> arrSong2;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_playlist );
        lvplaylist = findViewById( R.id.lvplaylist );

        arrStringSong = new ArrayList<String>();
        arrSong = new ArrayList<Song>();
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrStringSong);
        getPlaylist();
        AddSong();
        lvplaylist.setAdapter(adapter);

        lvplaylist.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                byExtras( i );
            }
        } );
    }

    private void getPlaylist() {
        Intent intent = getIntent();
        String playingSongName = intent.getStringExtra( OfflineList.TENBH );
        String playingSongSinger = intent.getStringExtra( OfflineList.TenCS );
        String playingSongKind = intent.getStringExtra( OfflineList.TheLoai );
        String playingSongAlbum = intent.getStringExtra( OfflineList.TenAB );
        String playingSongLink = intent.getStringExtra( OfflineList.Link );
        String playingSongFile = intent.getStringExtra( OfflineList.File );
        playingSong = new Song( playingSongName, playingSongKind, playingSongLink, playingSongAlbum, playingSongSinger, playingSongFile );
    }

    private void AddSong() {

        arrStringSong.add(playingSong.getTenBH()+ " - " + playingSong.getTenCS());
        arrSong.add(playingSong);
        adapter.notifyDataSetChanged();

    }

    public void byExtras(int position) {
        Intent intent = new Intent( Playlist.this, PlayMusic.class );
        intent.putExtra( "ListSize", arrSong.size() );
        for (int i = 0; i < arrSong.size(); i++) {
            intent.putExtra( "TENBH" + i, arrSong.get( i ).getTenBH() );
            intent.putExtra( "TenCS" + i, arrSong.get( i ).getTenCS() );
            intent.putExtra( "TenAB" + i, arrSong.get( i ).getTenAB() );
            intent.putExtra( "TheLoai" + i, arrSong.get( i ).getTheLoai() );
            intent.putExtra( "Link" + i, arrSong.get( i ).getLink() );
            intent.putExtra( "File" + i, arrSong.get( i ).getFile() );
        }
        intent.putExtra( "position", position );
        startActivity( intent );
    }
}
