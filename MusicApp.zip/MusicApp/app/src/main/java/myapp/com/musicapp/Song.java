package myapp.com.musicapp;

/**
 * Created by MSI on 4/8/2018.
 */

public class Song {
    private String TenBH, TheLoai, Link, TenAB,TenCS;
    private String File;
    public Song()
    {}

    public Song(String tenBH, String theLoai, String link, String tenAB, String tenCS, String file) {
        TenBH = tenBH;
        TheLoai = theLoai;
        Link = link;
        TenAB = tenAB;
        TenCS = tenCS;
        File = file;
    }

    public Song(String TenBH, String link, String tenCS) {
        this.TenBH = TenBH;
        Link = link;
        TenCS = tenCS;
    }

    public String getTheLoai() {
        return TheLoai;
    }

    public void setTheLoai(String theLoai) {
        TheLoai = theLoai;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        Link = link;
    }

    public String getTenAB() {
        return TenAB;
    }

    public void setTenAB(String tenAB) {
        TenAB = tenAB;
    }

    public String getTenBH() {
        return TenBH;
    }

    public void setTenBH(String TenBH) {
        this.TenBH = TenBH;
    }

    public String getTenCS() {
        return TenCS;
    }

    public void setTenCS(String tenCS) {
        TenCS = tenCS;
    }

    public String getFile() {
        return File;
    }

    public void setFile(String file) {
        File = file;
    }
}
