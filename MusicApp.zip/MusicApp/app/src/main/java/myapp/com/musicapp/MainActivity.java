package myapp.com.musicapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static MediaPlayer tempMediaPlayer;
    Button btnBaiHat, playList;
    ArrayList<Song> arrSong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        btnBaiHat = (Button) findViewById( R.id.btnbaiHat );
        btnBaiHat.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( MainActivity.this, OfflineList.class );
                startActivity( intent );
            }
        } );
        playList = findViewById( R.id.playList );
        playList.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( MainActivity.this, Playlist.class );
                startActivity( intent );
            }
        } );

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_online, menu );
        return super.onCreateOptionsMenu( menu );
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemHome:
                Intent intentHome = new Intent( MainActivity.this, ScreenHome.class );
                startActivity( intentHome );
                break;
            case R.id.itemRank:
                Intent intentRank = new Intent( MainActivity.this, ScreenRank.class );
                startActivity( intentRank );
                break;

        }
        return super.onOptionsItemSelected( item );
    }
}
